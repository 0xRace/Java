/**
 * @author Please put your name and the name of anyone who you worked with on this lab
 */

public class SumRunner
{
	public static void main( String[] args )
	{
		// instantiate a Sum object
		// I have named the reference test
	    Sum test = new Sum();
	    
	    // Call the mutator, sum, and print methods.
	    // I have done the first test case for you.
		test.setNums(5,5);
		test.sum();
		test.print();
 
		// You will need to add the other test cases given in sample data
		// Insert your code here!
		
	}
}