//Name - 
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class RecursionFunThreeRunner
{
	public static void main(String args[])
	{
		System.out.println(RecursionFunThree.luckySevens(1087171));
		System.out.println(RecursionFunThree.luckySevens(1077171));
		System.out.println(RecursionFunThree.luckySevens(77077));
		System.out.println(RecursionFunThree.luckySevens(97171771707797L));
		System.out.println(RecursionFunThree.luckySevens(1089651234));
	}
}