/**
 * AsciiBox
 * 
 * @author (your name and the name of anyone who you worked with on this lab) 
 * @version (a version number or a date)
 */

public class AsciiBox
{
    public static void main(String[] args)
    {
        System.out.println("Race \t  9/4 \n\n" );
        System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAA" );
        System.out.println("+++++++++++++++++++++++++++" );
        System.out.println("+++                     +++" );
        System.out.println("+++                     +++" );
        System.out.println("+++                     +++" );
        System.out.println("+++                     +++" );
        System.out.println("+++      CompSci        +++" );
        System.out.println("+++                     +++" );
        System.out.println("+++                     +++" );
        System.out.println("+++                     +++" );
        System.out.println("+++                     +++" );
        System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAA" );
        System.out.println("+++++++++++++++++++++++++++" );
        
        

    }
}