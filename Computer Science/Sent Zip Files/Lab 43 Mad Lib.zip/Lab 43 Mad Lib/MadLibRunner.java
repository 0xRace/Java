//Name - Race
//Date - 12-3
//Class -
//Lab  - 43

// You don't need to change this class

import static java.lang.System.*;

public class MadLibRunner
{
	public static void main( String args[] )
	{
		MadLib prog = new MadLib("story.dat");
		
		out.println("\n");
	}
}