//Name - 
//Date -
//Class - 
//Lab  - 

import static java.lang.System.*;

public class RecursionChickenRunner
{
	public static void main(String args[])
	{
		System.out.println(RecursionFunTwo.countChickens("itatfun"));
		
		System.out.println(RecursionFunTwo.countChickens("itatchickenfun"));
		
		System.out.println(RecursionFunTwo.countChickens("chchickchickenenicken"));	
			
		System.out.println(RecursionFunTwo.countChickens("chickchickfun"));;	
	
		System.out.println(RecursionFunTwo.countChickens("chickenbouncetheballchicken"));						
	}
}