public class Tester
{
    public static void main(String[] args)
    {
        //Cow c = new Cow();
        //System.out.println( c.getType() + " goes " + c.getSound() );
        // < your code here >
        // instantiate a Chick and a Pig and test their getType and getSound methods as above
        //Chick ch= new Chick();
        //System.out.println( ch.getType() + " goes " + ch.getSound() );
        //Pig p= new Pig();
        //System.out.println( p.getType() + " goes " + p.getSound() );
        Farm farm= new Farm();
        farm.animalSounds();
    }
}
