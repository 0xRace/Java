public class NamedCow extends Cow
{
    private String name;
    public NamedCow(String n)
    {
        super();
        name=n;
    }
    
    public String getName()
    {
        return name;
    }
}
