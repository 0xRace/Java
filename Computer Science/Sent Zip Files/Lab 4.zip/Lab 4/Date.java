/**
 * @author Pleae put your name and the name of anyone who you worked with on this lab
 */
public class Date
{
    public static void main(String[] args)
    {
        // assign variables
        String day= "Thursday";
        String month= "September";
        byte date= 17;
        short year= 2015;
        //print american format
        System.out.println("American format:");
        System.out.println(day+", "+month+" "+date+", "+year);
        //print european format
        System.out.println("European format:");
        System.out.println(day+" "+date+" "+month+", "+year);

    }
}
