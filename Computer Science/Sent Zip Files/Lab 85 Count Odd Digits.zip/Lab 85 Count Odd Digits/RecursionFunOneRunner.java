//Name - 
//Date -
//Class - 
//Lab  - 

import static java.lang.System.*;

public class RecursionFunOneRunner
{
	public static void main(String args[])
	{
		System.out.println(RecursionFunOne.countOddDigits(4532));

		System.out.println(RecursionFunOne.countOddDigits(1114532));
		
		System.out.println(RecursionFunOne.countOddDigits(2245327));		
			
		System.out.println(RecursionFunOne.countOddDigits(2468));	
	
		System.out.println(RecursionFunOne.countOddDigits(13579));							
	}
}