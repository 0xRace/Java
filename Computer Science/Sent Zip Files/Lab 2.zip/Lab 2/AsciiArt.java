/**
 * AsciiArt
 * 
 * @author (your name and the name of anyone who you worked with on this lab) 
 * @version (a version number or a date)
 */

public class AsciiArt
{
    public static void main ( String[] args )
    {
        System.out.println("Race\t  8/4\t Period 3\n\n" );
        System.out.println("What type of ANIMAL YOU WILL DRAW:A Bunny and it's carrot." );
        System.out.println("\n\n\n\n" );

        //carrot and a bunny
        System.out.println("  \\\\ | //    (\\ /)");
        System.out.println("  (    )     (-.- )");
        System.out.println("   (  )      (>  <)");
        System.out.println("    \\/       ^^ ^^ ");
        
    }
}